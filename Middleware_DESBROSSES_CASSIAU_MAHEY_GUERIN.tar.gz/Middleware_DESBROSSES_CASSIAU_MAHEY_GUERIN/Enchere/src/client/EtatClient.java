package client;

public enum EtatClient {
	ATTENTE,
	RENCHERI,
	TERMINE
}
