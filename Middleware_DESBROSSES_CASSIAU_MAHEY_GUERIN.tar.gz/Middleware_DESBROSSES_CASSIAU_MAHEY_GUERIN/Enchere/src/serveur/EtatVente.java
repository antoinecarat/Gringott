package serveur;

public enum EtatVente {
	ATTENTE,
	ENCHERISSEMENT,
	TERMINE;
}
